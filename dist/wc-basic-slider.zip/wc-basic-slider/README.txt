=== Unlimited Category slider for WooCommerce - With Related product Slider ===
Contributors: mamunur105
Tags: Slider, Category slider, Related product Slider, Promotional Product slider
Donate link: #
Requires at least: 5.0
Tested up to: 5.7
Requires PHP: 7.0
Stable tag: trunk
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This is for woocommerce Category slider,Related product slider, And also For Promotional basic slider

== Description ==
Everything is customizable. if you need more style you can customize css.
You will get Promotional slider, 2 types of Category slider, related product slider.

FEATURES LIST
	1. Unlimited Category slider with variation
	2. Related product slider.
	3. Promotional slider
	4. Add custom thumbnail.
	5. Compatible with any Theme
	6. Shortcode Generator.
	7. Display specific categories in the slider.
	8. Filter the list of categories you want to show. 
	9. Swiper, powerful, and fast loading.
	10. Responsive and mobile-ready.


Let's Take a look.

[youtube https://www.youtube.com/watch?v=H43D4AdS4o4&feature=youtu.be]

== Installation ==
Step 1. Download the Unlimited Category slider for WooCommerce ( wc-basic-slider ) plugin zip file from the Wordpress Plugin Repository.
Step 2. Upload \'wc-basic-slider\' to the ’/wp-content/plugins/\' directory
Step 3. Activate the plugin through the \'Plugins\' menu in WordPress


== Frequently Asked Questions ==
= How to show the slider? =
Use shortcode for showing the slider.

= How to show the related product slider? =
You just go to plugin setting and activate related product sider.

= Why plugin has no won design ? =
Related product will get the design from your theme. like as others product.
And Category slider also need to design like your style.
But any one can customize css his won style 

== Screenshots ==
1. Settings page
2. Promotional slider or main slider 
3. Category slider


== Changelog ==
= 2.1.0 =
Security update
= 2.0.0 =
Some feature update
= 1.0.2 =
Some feature update
= 1.0.0 =
* First active version, first launch

== Upgrade Notice ==
Please do update for latest version. 